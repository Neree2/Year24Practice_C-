#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    string a,b;
    cin>>a>>b;
    c=stoi(a)+stoi(b);
    cout<<c;
    return 0;}
