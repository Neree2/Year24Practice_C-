#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    ios_base::sync_with_stdio(0);cin.tie(0);
    for(int i=1;i<=n;i++){
        cout<<pow(i,2)<<" ";}
    return 0;
}
