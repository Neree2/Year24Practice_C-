#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    double o,a;
    cin>>o>>a;
    cout<<fixed<<setprecision(6)<<sqrt((a*a+o*o));
    return 0;
}
