#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main(){
    int n,m;
    cin>>n;
    ios_base::sync_with_stdio(0);cin.tie(0);
    string c;
    cin>>c;
    if(s.length()==n){
        cin>>m;
        for(int i=0;i<m;i++)
    }
    return 0;
}
