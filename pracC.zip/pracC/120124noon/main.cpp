#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    ios_base::sync_with_stdio(0);cin.tie(0);

    return 0;
}
