#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main(){
    int n,q;
    cin>>n>>q;
    int a[n],a[0]=0;
    for(int i=1;i<=n;i++){cin>>a[n];}
    return 0;
}
