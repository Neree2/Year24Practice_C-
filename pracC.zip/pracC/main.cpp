#include <iostream>
// include one of the file from standard library
// std=standard library
int main() {
    std::cout << "Hello World";
    return 0;
}
