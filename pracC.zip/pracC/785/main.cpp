#include <iostream>
#include <bits/std>
using namespace std;
int main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int k,n;
    cin>>n>>k;
    string a={"Never gonna give you up Never gonna let you down Never gonna run around and desert you Never gonna make you cry Never gonna say goodbye Never gonna tell a lie and hurt you"};
    return 0;
}
